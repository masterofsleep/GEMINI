require(shiny)
folder_address = 'C://Users//guoyi//Documents//Code//gemini//linkMRN'
runApp(folder_address, launch.browser=TRUE)